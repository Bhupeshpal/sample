package com.banking.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.banking.model.Account;
import com.banking.model.Beneficiary;
import com.banking.model.Team;
import com.banking.service.AccountService;
import com.banking.service.BeneficiaryService;
import com.banking.service.TeamService;


@Controller
public class BankController {
    
    @Autowired
	private AccountService accountService;
    
    @Autowired
    private BeneficiaryService beneficiaryService;

    /* IUserService userService;

    public void setUserService(IUserService userService) {
	this.userService = userService;
    }*/

    @RequestMapping("/LoginView")
    public String showLoginView(Model model) {
	model.addAttribute("authuser", new AuthorizedUser());
	String view = "LoginView";

	return view;
    }

    /*
     * @RequestMapping("/registerPage") public String registerView(Model model) {
     * model.addAttribute("authuser", new AuthorizedUser()); String view =
     * "successPage";
     * 
     * AuthorizedUser authuser = null; this.userService.AddUser(authuser);
     * 
     * return view; }
     */

    @RequestMapping(value = "/registerPage", method = RequestMethod.POST)
    public String validateregistrationPage(@Valid @ModelAttribute("authuser") AuthorizedUser authuser,
	    BindingResult bindingResult, Model model, HttpServletRequest req) {

	String view = "";
	if (bindingResult.hasErrors()) {
	    view = "successPage";
	    return view;
	} else {
	    String username = req.getParameter("userEmail");
	    String password = req.getParameter("password");

	    /*
	     * System.out.println(username); System.out.println(password);
	     * System.out.println(authuser);
	     */
	    userService.AddUser(authuser);

	    view = "successPage";
	    return view;

	}
    }

    @RequestMapping(value = "/LoginVerification", method = RequestMethod.POST)
    public String LoginValidation(Model model, HttpServletRequest req) {
	String username = req.getParameter("username");
	String password = req.getParameter("password");

	System.out.println("this is password" + password);
	if (userService.verifyUser(username, password)) {
	    return "successPage";
	}
	return "LoginView";

    }

    @RequestMapping("/logout")
    public String logout(HttpSession session) {
	session.invalidate();
	return "LoginView";
    }

    /*
     * @RequestMapping(value = "/logout", method = RequestMethod.GET) public String
     * logout(HttpSession session) { session.removeAttribute("username"); return
     * "redirect:../LoginView"; }
     */
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    /*
     * Add Account Details
     * 
     */
    
	@RequestMapping(value = "/addAccount", method = RequestMethod.POST)
	public ModelAndView addAccount(@ModelAttribute Account account) {

		ModelAndView modelAndView = new ModelAndView("home");
		accountService.addAccount(account);

		String message = "Account Added Successfully.";
		modelAndView.addObject("message", message);

		return modelAndView;
	}

	
	/*
	 * Retrieve Account Details
	 * This same method can be used to show the account balance
	 * 
	 */
	@RequestMapping(value = "/get/{accountId}", method = RequestMethod.GET)
	public ModelAndView getAccountDetails(@PathVariable Integer accountId) {
		ModelAndView modelAndView = new ModelAndView("home");
		Account account = accountService.getAccountDetails(accountId);
		modelAndView.addObject("account", account);
		return modelAndView;
	}

	/*
	 * Add Beneficiary
	 * 
	 */
	@RequestMapping(value = "/addBeneficiary", method = RequestMethod.POST)
	public ModelAndView addBeneficiary(@ModelAttribute Beneficiary beneficiary) {

		ModelAndView modelAndView = new ModelAndView("home");
		beneficiaryService.addBeneficiary(beneficiary);
		String message = "Beneficiary Added Successfully.";
		modelAndView.addObject("message", message);

		return modelAndView;
	}
    
	
	/*
	 * Retrieve Benefitiary Details
	 */
	@RequestMapping(value = "/get/{beneficiaryId}", method = RequestMethod.GET)
	public ModelAndView getBenefitiary(@PathVariable Integer beneficiaryId) {
		ModelAndView modelAndView = new ModelAndView("home");

		Beneficiary beneficiary = beneficiaryService.getBeneficiary(beneficiaryId);
		modelAndView.addObject("beneficiary", beneficiary);

		return modelAndView;
	}
    
    
	
	/*
	 * Deposit Money to beneficiary Account 
	 * This method accepts three parameters
	 *  1. fromAccountId -- From Account (Payee Account Number)
	 *  2. toAccountId -- To Account (Beneficiary Account Number)
	 *  3. amountToTransfer -- Amount Of that needs to be transfered
	 *  4. TransferTyep -- NEFT(National Electronic Funds Transfer) / IMPS(Immediate Payment Service)
	 */
  
    
	@RequestMapping(value = "/depositAmount/{fromAccountId}/{toAccountId}/{amountToTransfer}/{transferType}", method = RequestMethod.POST)
	public ModelAndView depositAmount(@PathVariable Long fromAccountId,@PathVariable Long toAccountId,@PathVariable Long amountToTransfer,@PathVariable String transferType ) {

		ModelAndView modelAndView = new ModelAndView("home");
		String responseMessage = accountService.depositAmount(fromAccountId,toAccountId,amountToTransfer,transferType);
		modelAndView.addObject("message", responseMessage);
		return modelAndView;
	}
    
	
	/*
	 * Withdraw Money from account 
	 * 
	 */
	@RequestMapping(value = "/withdrawAmount/{fromAccountId}/{amountTowithdraw}", method = RequestMethod.POST)
	public ModelAndView withdrawAmount(@PathVariable Long fromAccountId,Long amountTowithdraw) {

		ModelAndView modelAndView = new ModelAndView("home");
		String responseMessage = accountService.withdrawAmount(fromAccountId,amountTowithdraw);
		modelAndView.addObject("message", responseMessage);
		return modelAndView;
	}
    
}
