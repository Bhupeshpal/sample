package com.banking.dao;

import com.banking.model.Account;
import com.banking.model.Team;

public interface AccountDAO {

	public void addAccount(Account account);

	public Account getAccountDetails(long accountId);

	public void updateAccount(Account account);
	
}
