package com.banking.dao;

import com.banking.model.Beneficiary;

public interface BeneficiaryDAO {

	public void addBeneficiary(Beneficiary beneficiary);

	public Beneficiary getBeneficiary(long beneficiaryId);

}
