package com.banking.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.banking.model.Beneficiary;

@Repository
public class BeneficiaryDAOImpl implements BeneficiaryDAO {

	@Autowired
	private SessionFactory sessionFactory;

	private Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	@Override
	public void addBeneficiary(Beneficiary beneficiary) {
		getCurrentSession().save(beneficiary);
	}

	@Override
	public Beneficiary getBeneficiary(long beneficiaryId) {
		Beneficiary beneficiary = (Beneficiary) getCurrentSession().get(Beneficiary.class, beneficiaryId);
		return beneficiary;
	}

}
