package com.banking.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="account")
public class Account {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	private String title;
	private String firstName;
	private String middleName;
	private String lastName;
	private String fathersName;
	private String mobileNumber;
	private String aadharNumber;
	private String dob;
	
	
	//Account Balance
	private long accountBalance; 
	
	//Residential Address
	private String rAddress1;
	private String rAddress2;
	private String rlandMark;
	private String rstate;
	private String rcity;
	private String rpinCode;
	
	//Permanent Address
	private String pAddress1;
	private String pAddress2;
	private String plandMark;
	private String pstate;
	private String pcity;
	private String ppinCode;
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFathersName() {
		return fathersName;
	}
	public void setFathersName(String fathersName) {
		this.fathersName = fathersName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getAadharNumber() {
		return aadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getrAddress1() {
		return rAddress1;
	}
	public void setrAddress1(String rAddress1) {
		this.rAddress1 = rAddress1;
	}
	public String getrAddress2() {
		return rAddress2;
	}
	public void setrAddress2(String rAddress2) {
		this.rAddress2 = rAddress2;
	}
	public String getRlandMark() {
		return rlandMark;
	}
	public void setRlandMark(String rlandMark) {
		this.rlandMark = rlandMark;
	}
	public String getRstate() {
		return rstate;
	}
	public void setRstate(String rstate) {
		this.rstate = rstate;
	}
	public String getRcity() {
		return rcity;
	}
	public void setRcity(String rcity) {
		this.rcity = rcity;
	}
	public String getRpinCode() {
		return rpinCode;
	}
	public void setRpinCode(String rpinCode) {
		this.rpinCode = rpinCode;
	}
	public String getpAddress1() {
		return pAddress1;
	}
	public void setpAddress1(String pAddress1) {
		this.pAddress1 = pAddress1;
	}
	public String getpAddress2() {
		return pAddress2;
	}
	public void setpAddress2(String pAddress2) {
		this.pAddress2 = pAddress2;
	}
	public String getPlandMark() {
		return plandMark;
	}
	public void setPlandMark(String plandMark) {
		this.plandMark = plandMark;
	}
	public String getPstate() {
		return pstate;
	}
	public void setPstate(String pstate) {
		this.pstate = pstate;
	}
	public String getPcity() {
		return pcity;
	}
	public void setPcity(String pcity) {
		this.pcity = pcity;
	}
	public String getPpinCode() {
		return ppinCode;
	}
	public void setPpinCode(String ppinCode) {
		this.ppinCode = ppinCode;
	}
	public long getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(long accountBalance) {
		this.accountBalance = accountBalance;
	}

}
