package com.banking.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.banking.dao.AccountDAO;
import com.banking.model.Account;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDAO accountDAO;

	@Override
	public void addAccount(Account account) {
		accountDAO.addAccount(account);
	}

	@Override
	public Account getAccountDetails(long accountId) {
		return accountDAO.getAccountDetails(accountId);
	}

	@Override
	public String depositAmount(long fromAccountId, long toAccountId, long amountToTransfer, String transferType) {

		String responseMessage = "";

		Account fromAccount = accountDAO.getAccountDetails(fromAccountId);
		Account toAccount = accountDAO.getAccountDetails(toAccountId);

		// Assuming that NEFT will be carried out in a standard bank timings i.e. 9 AM to 5 PM

		if ("NEFT".equalsIgnoreCase(transferType)) {
			
			// Add logic (in below if condition, instead of true) to check if the current time is in between the 9 am to 5 pm
			if(true)
				
			return "NEFT transaction can be performed in office hours only i.e. 9 AM to 5 PM";

		} else if ("IMPS".equalsIgnoreCase(transferType)) {
			if (amountToTransfer > 200000) {
				return "IMPS transaction cant process amount greater than 2 Lakhs";
			}
		} else if (fromAccount.getAccountBalance() < amountToTransfer) {
			return "Insufficient Fund";
		}

		long currentBalance = toAccount.getAccountBalance();
		long updateBalance = currentBalance + amountToTransfer;

		toAccount.setAccountBalance(updateBalance);

		accountDAO.updateAccount(toAccount);
		
		responseMessage = "Amount "+amountToTransfer+" deposited to "+toAccountId + " from "+fromAccountId +"On "+new Date() +"Using "+transferType +"Mode of payment";

		return responseMessage;

	}
	
	
	
	@Override
	public String withdrawAmount(long accountId, long amountTowithdraw) {

		String responseMessage = "";
		long currentBalance;
		long updateBalance;

		Account account = accountDAO.getAccountDetails(accountId);

		if(amountTowithdraw>account.getAccountBalance()) {
			return "Insufficient Fund";
		}else {
			currentBalance = account.getAccountBalance();
			updateBalance = currentBalance - amountTowithdraw;
			
		}
		account.setAccountBalance(updateBalance);
		accountDAO.updateAccount(account);
		responseMessage = "Amount "+amountTowithdraw+" withdrawn from "+accountId +" On "+new Date();
		return responseMessage;

	}

}
