package com.banking.service;

import com.banking.model.Beneficiary;

public interface BeneficiaryService {

	public void addBeneficiary(Beneficiary beneficiary);

	public Beneficiary getBeneficiary(long beneficiaryId);

}
