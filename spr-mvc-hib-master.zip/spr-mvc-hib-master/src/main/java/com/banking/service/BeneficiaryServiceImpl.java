package com.banking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.banking.dao.BeneficiaryDAO;
import com.banking.model.Beneficiary;

@Service
@Transactional
public class BeneficiaryServiceImpl implements BeneficiaryService {
	
	@Autowired
	private BeneficiaryDAO beneficiaryDAO;

	@Override
	public void addBeneficiary(Beneficiary beneficiary) {
		beneficiaryDAO.addBeneficiary(beneficiary);		
	}

	@Override
	public Beneficiary getBeneficiary(long beneficiaryId) {
		return beneficiaryDAO.getBeneficiary(beneficiaryId);
	}


}
